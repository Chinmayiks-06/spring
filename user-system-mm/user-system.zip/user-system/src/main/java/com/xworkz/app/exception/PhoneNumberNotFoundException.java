package com.xworkz.app.exception;

public class PhoneNumberNotFoundException extends RuntimeException{
    public PhoneNumberNotFoundException(String message){
        super(message);
    }

}
