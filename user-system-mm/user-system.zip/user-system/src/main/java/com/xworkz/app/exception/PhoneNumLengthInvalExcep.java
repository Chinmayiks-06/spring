package com.xworkz.app.exception;

public class PhoneNumLengthInvalExcep extends RuntimeException{
    public PhoneNumLengthInvalExcep(String msg){
        super(msg);
    }

}
